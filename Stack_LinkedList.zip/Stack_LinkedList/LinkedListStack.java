public class LinkedListStack{
    
LinkedList li= new LinkedList();
public void push(int element){
    li.insertFirst(element);
    
}
public void pop(){
    li.deleteFirst();
}
public void displayStack(){
    System.out.println(" ");
    li.displayList();
}
}