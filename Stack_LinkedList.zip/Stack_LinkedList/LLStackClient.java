
public class LLStackClient{
    public static void main(String[] args){
    LinkedListStack st = new LinkedListStack();
    st.push(50);
    st.push(190);
    st.push(70);
    System.out.println("1. Stack after push operation: ");
    st.displayStack();
    System.out.println("2. Stack after pop operation: ");
    st.pop();
    st.displayStack();
    }
}