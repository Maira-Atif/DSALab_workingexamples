 class LinkedList{
    private Node top;
public static class Node{
    
public int data;
public Node next;

public Node(int data){
    this.data=data;
    
}
}
public void insertFirst(int data){
    Node n= new Node(data);
    n.next=top;
    top=n;
    
}
public Node deleteFirst(){
    Node temp=top;
    top=top.next;
    return temp;
}
public void displayList(){
    Node current =top;
    while(current!=null){
        System.out.println(current.data);
        current=current.next;
    }
}
}

